jQuery(function ($) {
    console.log('js enable');
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
});